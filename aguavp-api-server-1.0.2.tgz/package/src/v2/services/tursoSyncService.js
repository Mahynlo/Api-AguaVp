/**
 * Servicio de Sincronización Espejo con Turso Cloud
 * File: src/v2/services/tursoSyncService.js
 *
 * Responsabilidades:
 * - Probar conectividad con la base de datos de Turso
 * - Carga semilla inicial (Seed) de la estructura y datos locales hacia la nube
 * - Sincronización incremental periódica y manual de cambios locales hacia Turso
 * - Resiliencia offline: fallos de red no interrumpen el servidor local
 */

import { createClient } from '@libsql/client';
import dbWrapper, { sqlite } from '../../database/db-sqlite.js';

// Estado en memoria del servicio
let tursoClient = null;
let syncConfig = {
    tursoUrl: process.env.TURSO_DATABASE_URL || '',
    tursoToken: process.env.TURSO_AUTH_TOKEN || '',
    autoSync: true,
    syncIntervalMs: 5 * 60 * 1000 // 5 minutos
};

let syncState = {
    inProgress: false,
    lastSync: null,
    lastSyncSuccess: null,
    lastError: null,
    totalRecordsSynced: 0
};

let syncTimer = null;

// Orden de tablas para respetar dependencias de claves foráneas
const TABLE_SYNC_ORDER = [
    '__drizzle_migrations',
    'apps',
    'auditoria_seguridad',
    'historial_passwords',
    'refresh_tokens',
    'sesiones',
    'tokens_revocados',
    'usuarios',
    'configuracion_servicio',
    'tarifas',
    'rangos_tarifas',
    'historial_tarifas',
    'rutas',
    'clientes',
    'medidores',
    'rutas_puntos',
    'cliente_medidor_historial',
    'lecturas',
    'facturas',
    'pagos',
    'convenios_pago',
    'parcialidades_convenio',
    'cortes_servicio',
    'historial_cambios'
];

/**
 * Prueba la conectividad con una base de datos en Turso
 * @param {string} url - URL de la base de Turso (libsql://...)
 * @param {string} token - Token de autenticación JWT
 * @returns {Promise<{ ok: boolean, latencyMs: number }>}
 */
export async function testConnection(url, token) {
    if (!url || !token) {
        throw new Error('URL y Token de Turso son obligatorios');
    }

    const testClient = createClient({
        url: url.trim(),
        authToken: token.trim()
    });

    const start = Date.now();
    await testClient.execute('SELECT 1 as ping');
    const latencyMs = Date.now() - start;

    return { ok: true, latencyMs };
}

/**
 * Inicializa o reconfigura el servicio de sincronización
 * @param {Object} config - { tursoUrl, tursoToken, autoSync, syncIntervalMs }
 */
export function configure(config = {}) {
    if (config.tursoUrl !== undefined) syncConfig.tursoUrl = (config.tursoUrl || '').trim();
    if (config.tursoToken !== undefined) syncConfig.tursoToken = (config.tursoToken || '').trim();
    if (config.autoSync !== undefined) syncConfig.autoSync = Boolean(config.autoSync);
    if (config.syncIntervalMs) syncConfig.syncIntervalMs = Number(config.syncIntervalMs);

    // Reiniciar timer previo
    if (syncTimer) {
        clearInterval(syncTimer);
        syncTimer = null;
    }

    if (syncConfig.tursoUrl && syncConfig.tursoToken) {
        try {
            tursoClient = createClient({
                url: syncConfig.tursoUrl,
                authToken: syncConfig.tursoToken
            });
            console.log(`[TursoSync] Conectado a la base remota: ${syncConfig.tursoUrl}`);

            if (syncConfig.autoSync) {
                syncTimer = setInterval(() => {
                    syncIncremental().catch(err => {
                        console.warn('[TursoSync] Error en sync automático (silencioso):', err.message);
                    });
                }, syncConfig.syncIntervalMs);
            }
        } catch (err) {
            console.error('[TursoSync] Error inicializando cliente Turso:', err.message);
            tursoClient = null;
        }
    } else {
        tursoClient = null;
        console.log('[TursoSync] Modo local puro — sin credenciales de Turso configuradas');
    }

    return getStatus();
}

/**
 * Obtiene el estado actual de sincronización
 */
export function getStatus() {
    return {
        configured: Boolean(syncConfig.tursoUrl && syncConfig.tursoToken),
        tursoUrl: syncConfig.tursoUrl ? syncConfig.tursoUrl.replace(/:[^@]+@/, ':***@') : null,
        autoSync: syncConfig.autoSync,
        inProgress: syncState.inProgress,
        lastSync: syncState.lastSync,
        lastSyncSuccess: syncState.lastSyncSuccess,
        lastError: syncState.lastError,
        totalRecordsSynced: syncState.totalRecordsSynced
    };
}

/**
 * Carga Semilla Inicial: Copia esquema y datos locales completos hacia Turso
 * Se utiliza cuando la base de Turso es nueva o se conecta por primera vez
 */
export async function seedDatabase() {
    if (!tursoClient) {
        throw new Error('El cliente de Turso no está configurado');
    }
    if (syncState.inProgress) {
        throw new Error('Una sincronización ya se encuentra en progreso');
    }

    syncState.inProgress = true;
    syncState.lastError = null;
    console.log('[TursoSync] 🚀 Iniciando carga semilla inicial hacia Turso...');

    try {
        // 1. Obtener todas las tablas locales de SQLite
        const tables = sqlite.prepare(`
            SELECT name, sql FROM sqlite_master 
            WHERE type='table' 
              AND name NOT LIKE 'sqlite_%' 
            ORDER BY name
        `).all();

        const tableMap = new Map(tables.map(t => [t.name, t.sql]));

        // 2. Crear las tablas en Turso si no existen
        for (const tableName of TABLE_SYNC_ORDER) {
            const createSql = tableMap.get(tableName);
            if (createSql) {
                try {
                    // Asegurar CREATE TABLE IF NOT EXISTS
                    const safeSql = createSql.replace(/CREATE TABLE\s+(?!IF NOT EXISTS)/i, 'CREATE TABLE IF NOT EXISTS ');
                    await tursoClient.execute(safeSql);
                } catch (err) {
                    console.warn(`[TursoSync] Aviso creando tabla ${tableName} en Turso:`, err.message);
                }
            }
        }

        // 3. Crear índices
        const indexes = sqlite.prepare(`
            SELECT sql FROM sqlite_master 
            WHERE type='index' 
              AND sql IS NOT NULL 
              AND name NOT LIKE 'sqlite_%'
        `).all();

        for (const idx of indexes) {
            try {
                const safeIdxSql = idx.sql.replace(/CREATE INDEX\s+(?!IF NOT EXISTS)/i, 'CREATE INDEX IF NOT EXISTS ');
                await tursoClient.execute(safeIdxSql);
            } catch (err) {
                // Índices únicos o existentes pueden ignorarse
            }
        }

        // 4. Desactivar Foreign Keys en Turso temporalmente para la carga masiva
        try {
            await tursoClient.execute('PRAGMA foreign_keys = OFF;');
        } catch (_) {}

        let totalRows = 0;
        const tablesCopied = [];

        // 5. Copiar datos tabla por tabla en lotes
        for (const tableName of TABLE_SYNC_ORDER) {
            if (!tableMap.has(tableName)) continue;

            const rows = sqlite.prepare(`SELECT * FROM "${tableName}"`).all();
            if (rows.length === 0) continue;

            const columns = Object.keys(rows[0]);
            const placeholders = columns.map(() => '?').join(', ');
            const insertSql = `INSERT OR REPLACE INTO "${tableName}" (${columns.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`;

            // Dividir en lotes de 100 registros para Turso batch
            const BATCH_SIZE = 100;
            for (let i = 0; i < rows.length; i += BATCH_SIZE) {
                const chunk = rows.slice(i, i + BATCH_SIZE);
                const statements = chunk.map(row => ({
                    sql: insertSql,
                    args: columns.map(c => {
                        const val = row[c];
                        // Convertir booleanos o fechas si es necesario
                        if (typeof val === 'boolean') return val ? 1 : 0;
                        return val;
                    })
                }));

                await tursoClient.batch(statements, 'write');
            }

            totalRows += rows.length;
            tablesCopied.push({ table: tableName, count: rows.length });
            console.log(`[TursoSync] ✓ Tabla ${tableName} copiada (${rows.length} registros)`);
        }

        // 6. Restaurar Foreign Keys
        try {
            await tursoClient.execute('PRAGMA foreign_keys = ON;');
        } catch (_) {}

        syncState.lastSync = new Date().toISOString();
        syncState.lastSyncSuccess = true;
        syncState.totalRecordsSynced += totalRows;

        console.log(`[TursoSync] ✅ Carga semilla completada exitosamente. Total registros: ${totalRows}`);
        return {
            success: true,
            totalRows,
            tablesCopied,
            timestamp: syncState.lastSync
        };
    } catch (error) {
        syncState.lastSyncSuccess = false;
        syncState.lastError = error.message;
        console.error('[TursoSync] ❌ Error en carga semilla:', error);
        throw error;
    } finally {
        syncState.inProgress = false;
    }
}

/**
 * Sincronización Incremental: Envía registros modificados o nuevos
 */
export async function syncIncremental() {
    if (!tursoClient) return { success: false, reason: 'unconfigured' };
    if (syncState.inProgress) return { success: false, reason: 'already_running' };

    // Si nunca se ha hecho sync previo, ejecutamos la semilla
    if (!syncState.lastSync) {
        return await seedDatabase();
    }

    syncState.inProgress = true;
    syncState.lastError = null;

    try {
        const lastSync = syncState.lastSync;
        let syncedCount = 0;

        // Tablas transaccionales principales con fecha
        const dateTables = [
            { name: 'clientes', col: 'fecha_creacion' },
            { name: 'medidores', col: 'fecha_creacion' },
            { name: 'lecturas', col: 'fecha_creacion' },
            { name: 'facturas', col: 'fecha_creacion' },
            { name: 'pagos', col: 'fecha_creacion' },
            { name: 'historial_cambios', col: 'fecha_modificacion' },
            { name: 'cortes_servicio', col: 'fecha_creacion' },
            { name: 'convenios_pago', col: 'fecha_creacion' }
        ];

        for (const item of dateTables) {
            // Verificar si la columna existe antes de consultar
            try {
                const rows = sqlite.prepare(
                    `SELECT * FROM "${item.name}" WHERE "${item.col}" >= ?`
                ).all(lastSync);

                if (rows.length > 0) {
                    const columns = Object.keys(rows[0]);
                    const placeholders = columns.map(() => '?').join(', ');
                    const sql = `INSERT OR REPLACE INTO "${item.name}" (${columns.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`;

                    const statements = rows.map(r => ({
                        sql,
                        args: columns.map(c => r[c])
                    }));

                    await tursoClient.batch(statements, 'write');
                    syncedCount += rows.length;
                }
            } catch (err) {
                // Si la tabla no tiene esa columna o está vacía, continuar
            }
        }

        // Catálogos pequeños (usuarios, tarifas, rangos, configuración):
        // Se sincronizan completos con INSERT OR REPLACE si hay cambios
        const smallCatalogs = ['configuracion_servicio', 'tarifas', 'rangos_tarifas', 'usuarios', 'rutas'];
        for (const cat of smallCatalogs) {
            try {
                const rows = sqlite.prepare(`SELECT * FROM "${cat}"`).all();
                if (rows.length > 0) {
                    const columns = Object.keys(rows[0]);
                    const placeholders = columns.map(() => '?').join(', ');
                    const sql = `INSERT OR REPLACE INTO "${cat}" (${columns.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`;

                    const statements = rows.map(r => ({
                        sql,
                        args: columns.map(c => r[c])
                    }));

                    await tursoClient.batch(statements, 'write');
                }
            } catch (_) {}
        }

        syncState.lastSync = new Date().toISOString();
        syncState.lastSyncSuccess = true;
        syncState.totalRecordsSynced += syncedCount;

        return {
            success: true,
            syncedCount,
            timestamp: syncState.lastSync
        };
    } catch (error) {
        syncState.lastSyncSuccess = false;
        syncState.lastError = error.message;
        console.warn('[TursoSync] Aviso durante sync incremental:', error.message);
        return {
            success: false,
            error: error.message
        };
    } finally {
        syncState.inProgress = false;
    }
}

export default {
    testConnection,
    configure,
    getStatus,
    seedDatabase,
    syncIncremental
};
